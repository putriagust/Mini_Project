package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import net.thucydides.core.annotations.Steps;
import starter.page.Cart;
import starter.page.Transaction;

public class CartStep {
    @Steps
    Cart cart;

    Transaction transaction;

    @Given("I am on the cart page")
    public void cartPage(){
        cart.validateOnCartPage();
    }

    @When("I click the + button to add a product")
    public void plusButton(){
        cart.toTambahButton();
    }

    @And("I click the - button to reduce the product")
    public void minusButton(){
        cart.toKurangButton();
    }

    @And("I click the bayar button to complete the transaction")
    public void bayarButtonToComplete(){
        cart.toBeliButton();
    }

    @Then("transaction is success")
    public void transactionSuccess(){
        transaction.validateOnTransactionPage();
    }

    @Then("I can see message {string}")
    public void iCanSeeMessage(String message) {
        cart.validateMessageDisplayed();
        cart.validateEqualMessageInCart(message);
    }
}
