package starter.page;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Detail extends PageObject {
    private By details(){
        return By.xpath("//*[@id=\"app\"]/div/main/div/div/div/div/div/div/div");
    }

    private By noNotif(){
        return By.xpath("//*[@id=\"app\"]/div/header/div/button[1]/span/span/span/span");
    }

    @Step
    public void validateOnDetailsPage(){
        $(details()).isDisabled();
    }

    @Step
    public boolean noNotifCart(){
        return !$(noNotif()).isDisplayed();
    }
}
