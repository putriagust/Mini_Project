package starter.page;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Home extends PageObject {
    private By home(){
        return By.xpath("//*[@id=\"app\"]//label");
    }

    private By buyButtonProduct1(){
        return By.xpath("//*[@id=\"525\"]//button[2]");
    }

    private By buyButtonProduct2(){
        return By.xpath("//*[@id=\"534\"]//button[2]");
    }

    private By notif(){
        return By.xpath("//*[@id=\"app\"]/div/header/div/button[1]/span/span/span/span");
    }

    private By detailButtonProduct1(){
        return By.xpath("//*[@id=\"531\"]//button[1]");
    }

    @Step
    public void validateOnHomePage(){
        $(home()).isDisabled();
    }

    @Step
    public void beliButtonProduct1() {
        $(buyButtonProduct1()).click();
    }

    @Step
    public void beliButtonProduct2() {
        $(buyButtonProduct2()).click();
    }

    @Step
    public boolean notifikasiCart(){
        return $(notif()).isDisplayed();
    }

    @Step
    public void detailsProduct(){
        $(detailButtonProduct1()).click();
    }
}
