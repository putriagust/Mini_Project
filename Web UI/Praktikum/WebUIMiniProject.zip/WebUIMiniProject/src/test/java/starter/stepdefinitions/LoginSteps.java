package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.page.Home;
import starter.page.Login;

public class LoginSteps {

    @Steps
    Login login;

    @Steps
    Home home;

    @Given("I am on the login page")
    public void loginPage(){
        login.validateOnLoginPage();
    }

    @When("I input my valid email")
    public void inputEmailValid(){
        login.inputEmail("emailalta_benar@gmail.com");
    }

    @And("I input password correctly")
    public void inputPasswordValid(){
        login.inputPassword("sandiBenar");
    }

    @And("I click login button")
    public void clickLoginButton(){
        login.clickButton();
    }

    @Then("I go to home page")
    public void onTheHomePage(){
        home.validateOnHomePage();
    }

    @When("I input my invalid email")
    public void inputInvalidEmail(){
        login.inputEmail("salah@mail.com");
    }

    @Then("I can see error message {string}")
    public void iCanSeeErrorMessage(String message) {
        login.validateErrorMessageDisplayed();
        login.validateEqualMessage(message);
    }

    @When("I entered the password incorrectly")
    public void inputInvalidPass(){
        login.inputPassword("sandiSalah");
    }
}
