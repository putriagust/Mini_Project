package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.page.Cart;
import starter.page.Login;
import starter.page.Transaction;

public class TransactionSteps {
    @Steps
    Transaction transaction;
    Cart cart;
    Login login;

    @Given("I am on the cart page to buy product")
    public void cartPageToBuyProduct(){
        cart.validateOnCartPage();
    }

    @When("I click the bayar button")
    public void clickTheBayarButton(){
        transaction.bayarButtonInCart();
    }

    @And("I go to login page to login")
    public void goToLoginToLogin(){
        login.validateOnLoginPage();
    }

    @And("I input valid mail")
    public void inputValidMail(){
        login.inputEmail("emailalta_benar@gmail.com");
    }

    @And("I input valid pass")
    public void inputValidPass(){
        login.inputPassword("sandiBenar");
    }

    @Then("I go to the transaction page")
    public void goToTheTransactionpage(){
        transaction.validateOnTransactionPage();
    }
}
