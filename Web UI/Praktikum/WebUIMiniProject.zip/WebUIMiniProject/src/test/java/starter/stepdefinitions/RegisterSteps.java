package starter.stepdefinitions;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.page.Login;
import starter.page.Register;

public class RegisterSteps {

    @Steps
    Register register;

    Login login;

    Faker faker = new Faker();

    @Given("I am on the register page")
    public void registerPage(){
        register.validateOnRegisPage();
    }

    @When("I input valid full name")
    public void inputValidFullName(){
        register.inputFullName(faker.name().fullName());
    }

    @And("I input valid email")
    public void inputEmail(){
        register.inputEmail(faker.internet().emailAddress());
    }

    @And("I input valid password")
    public void inputPassword(){
        register.inputPassword(faker.internet().password(5, 9));
    }

    @And("I click register button")
    public void clickRegisterButton(){
        register.clickRegisButton();
    }

    @Then("I go to login page")
    public void goToLoginPage(){
        login.validateOnLoginPage();
    }

    @Then("I can see error messages {string}")
    public void iCanSeeErrorMessage(String messages) {
        login.validateErrorMessageDisplayed();
        login.validateEqualMessage(messages);
    }
}
