package starter.page;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Cart extends PageObject {
    private By cart() {
        return By.xpath("//*[@id=\"button-bayar\"]");
    }

    private By tambahButton() {
        return By.xpath("//*[@id=\"order-525\"]/div[2]/button[2]/span");
    }

    private By kurangButton() {
        return By.xpath("//*[@id=\"order-534\"]/div[2]/button[1]/span");
    }
/*
    private By notif() {
        return By.xpath("//*[@id=\"app\"]/div/header/div/button[1]/span/span/span/span");
    }
*/
    private By empty() {
        return By.xpath("//*[@class='v-icon notranslate v-alert__icon fas fa-info-circle theme--light info--text']");
    }

    @Step
    public void validateOnCartPage() {
        $(cart()).isDisabled();
    }

    @Step
    public void toTambahButton() {
        $(tambahButton()).click();
    }

    @Step
    public void toKurangButton() {
        $(kurangButton()).click();
    }

    @Step
    public void toBeliButton() {
        $(cart()).click();
    }


    /*@Step
    public void notifikasiCart(){
        $(notif()).getElement();
    }*/

    @Step
    public boolean validateMessageDisplayed() {
        return $(empty()).isDisplayed();
    }

    @Step
    public boolean validateEqualMessageInCart(String message) {
        return $(empty()).getText().equalsIgnoreCase(message);
    }
}
