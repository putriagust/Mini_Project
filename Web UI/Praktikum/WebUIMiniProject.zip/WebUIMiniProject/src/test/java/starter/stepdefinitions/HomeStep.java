package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.page.Cart;
import starter.page.Detail;
import starter.page.Home;

public class HomeStep {
    @Steps
    Home home;
    Cart cart;
    Detail detail;

    @Given("I am on the home page")
    public void homePage() {
        home.validateOnHomePage();
    }

    @When("I click beli button in one product")
    public void buyButton1() {
        home.beliButtonProduct1();
    }

    @And("I click beli button on another product")
    public void buyButton2() {
        home.beliButtonProduct2();
    }

    @Then("the cart will be filled 2 products")
    public void filled2Products() {
        cart.validateOnCartPage();
    }

    @Then("the cart will be notification 2 products")
    public void notifProductInCart(){
        home.notifikasiCart();
    }

    @When("I click detail button in one product")
    public void detailsProductButton(){
        home.detailsProduct();
    }

    @And("I go to details page")
    public void goToDetailsProduct(){
        detail.validateOnDetailsPage();
    }
    @Then("no product notifications in cart")
    public void noProductNotifInCart(){
        detail.noNotifCart();
    }
}
