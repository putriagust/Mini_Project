package starter.page;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Login extends PageObject {
    private By emailField(){
        return By.xpath("//*[label[text()='Email']]/input");
    }

    private By passwordField(){
        return By.xpath("//*[label[text()='Password']]/input");
    }

    private By loginButton(){
        return By.xpath("//*[@class='v-btn v-btn--is-elevated v-btn--has-bg theme--light v-size--default primary']//*[@class='v-btn__content']");
    }

    private By errorLogin(){
        return By.xpath("//*[@class='v-icon notranslate v-alert__icon fas fa-exclamation-triangle theme--light error--text']");
    }

    @Step
    public void validateOnLoginPage(){
        $(loginButton()).isDisabled();
    }

    @Step
    public void inputEmail(String email){
        $(emailField()).type(email);
    }

    @Step
    public void inputPassword(String pass){
        $(passwordField()).type(pass);
    }

    @Step
    public void clickButton(){
        $(loginButton()).click();
    }

    @Step
    public boolean validateErrorMessageDisplayed(){
        return $(errorLogin()).isDisplayed();
    }

    @Step
    public boolean validateEqualMessage(String message){
        return $(errorLogin()).getText().equalsIgnoreCase(message);
    }
}
