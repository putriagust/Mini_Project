package starter.page;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Register extends PageObject {
    private By myFullName(){
        return By.xpath("//*[label[text()='Nama Lengkap']]/input");
    }

    private By email(){
        return By.xpath("//*[label[text()='Email']]/input");
    }

    private By password(){
        return By.xpath("//*[label[text()='Password']]/input");
    }

    private By regisButton(){
        return By.xpath("//*[@class='v-btn v-btn--is-elevated v-btn--has-bg theme--light v-size--default primary']/*[@class='v-btn__content']");
    }

    private By errorRegis(){
        return By.xpath("//*[@class='v-icon notranslate v-alert__icon fas fa-exclamation-triangle theme--light error--text']");
    }

    @Step
    public void validateOnRegisPage(){
        $(regisButton()).isDisabled();
    }

    @Step
    public void inputFullName(String fullName) {
        $(myFullName()).type(fullName);
    }

    @Step
    public void inputEmail(String email) {
        $(email()).type(email);
    }

    @Step
    public void inputPassword(String pswd){
        $(password()).type(pswd);
    }

    @Step
    public void clickRegisButton(){
        $(regisButton()).click();
    }

    @Step
    public boolean validateErrorMessageDisplayed(){
        return $(errorRegis()).isDisplayed();
    }

    @Step
    public boolean validateEqualMessage(String messages){
        return $(errorRegis()).getText().equalsIgnoreCase(messages);
    }
}
