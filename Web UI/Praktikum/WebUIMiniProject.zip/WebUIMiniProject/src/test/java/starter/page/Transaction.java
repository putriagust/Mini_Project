package starter.page;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Transaction extends PageObject {
    private By transaction(){
        return By.xpath("//*[@id=\"app\"]//h1");
    }

    private By bayar(){
        return By.xpath("//*[@id=\"669\"]//button[2]");
    }

    @Step
    public void validateOnTransactionPage(){
        $(transaction()).isDisabled();
    }

    @Step
    public void bayarButtonInCart(){
        $(bayar()).click();
    }
}
